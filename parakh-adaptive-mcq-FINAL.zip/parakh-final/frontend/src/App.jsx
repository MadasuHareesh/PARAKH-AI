import { useEffect, useState } from "react";
import { getMe } from "./services/api";
import LoginPage from "./pages/LoginPage";
import Dashboard from "./pages/Dashboard";
import AssessmentPage from "./pages/AssessmentPage";
import ResultsPage from "./pages/ResultsPage";
import AdminDashboard from "./pages/AdminDashboard";
import Topbar from "./components/Topbar";

export default function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState("dashboard");
  const [mode, setMode] = useState(null);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("parakh_token");
    if (!token) {
      setBooting(false);
      return;
    }

    getMe()
      .then((res) => setUser(res.data))
      .catch(() => localStorage.removeItem("parakh_token"))
      .finally(() => setBooting(false));
  }, []);

  function logout() {
    localStorage.removeItem("parakh_token");
    setUser(null);
    setView("dashboard");
    setMode(null);
  }

  function startAssessment() {
    setMode("pre_assessment");
    setView("assessment");
  }

  if (booting) return <div className="loading">Starting PARAKH AI...</div>;

  if (!user) return <LoginPage onLogin={(u) => setUser(u)} />;

  if (view === "assessment") {
    return (
      <>
        <Topbar user={user} onLogout={logout} />
        <AssessmentPage
          mode={mode}
          onExit={() => {
            setView("dashboard");
            setMode(null);
          }}
        />
      </>
    );
  }

  return (
    <>
      <Topbar user={user} onLogout={logout} />
      <nav className="nav">
        <button className={view === "dashboard" ? "active" : ""} onClick={() => setView("dashboard")}>Dashboard</button>
        <button className={view === "results" ? "active" : ""} onClick={() => setView("results")}>Results</button>
        {user.role === "admin" && (
          <button className={view === "admin" ? "active" : ""} onClick={() => setView("admin")}>Admin</button>
        )}
      </nav>

      {view === "dashboard" && (
        <Dashboard
          user={user}
          onStart={startAssessment}
        />
      )}

      {view === "results" && <ResultsPage />}

      {view === "admin" && user.role === "admin" && <AdminDashboard />}
    </>
  );
}

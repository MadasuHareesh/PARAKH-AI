import { useEffect, useState } from "react";
import {
  getAdminAnalytics, getQuestions, addQuestion, deleteQuestion,
  getStudents, createStudent, resetStudent, deleteStudent,
} from "../services/api";

const initialQuestion = {
  question_text: "", option_a: "", option_b: "", option_c: "", option_d: "",
  correct_answer: "A", topic: "Programming", subtopic: "General",
  difficulty: 3, explanation: "", pre_assessment: false,
};

const initialStudent = { name: "", email: "", password: "" };

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [questions, setQuestions] = useState([]);
  const [students, setStudents] = useState([]);
  const [form, setForm] = useState(initialQuestion);
  const [studentForm, setStudentForm] = useState(initialStudent);
  const [studentError, setStudentError] = useState("");

  async function load() {
    const [s, q, st] = await Promise.all([getAdminAnalytics(), getQuestions(), getStudents()]);
    setStats(s.data);
    setQuestions(q.data);
    setStudents(st.data);
  }

  useEffect(() => { load(); }, []);

  function change(e) {
    const { name, value, type, checked } = e.target;
    setForm((f) => ({ ...f, [name]: type === "checkbox" ? checked : name === "difficulty" ? Number(value) : value }));
  }

  async function submit(e) {
    e.preventDefault();
    await addQuestion(form);
    setForm(initialQuestion);
    await load();
  }

  async function remove(id) {
    await deleteQuestion(id);
    await load();
  }

  function changeStudent(e) {
    setStudentForm((f) => ({ ...f, [e.target.name]: e.target.value }));
  }

  async function submitStudent(e) {
    e.preventDefault();
    setStudentError("");
    try {
      await createStudent(studentForm);
      setStudentForm(initialStudent);
      await load();
    } catch (err) {
      setStudentError(err?.response?.data?.detail || "Could not create student");
    }
  }

  async function handleReset(id) {
    if (!window.confirm("Reset this student's assessment? All attempts will be cleared.")) return;
    await resetStudent(id);
    await load();
  }

  async function handleDelete(id) {
    if (!window.confirm("Delete this student permanently? This cannot be undone.")) return;
    await deleteStudent(id);
    await load();
  }

  if (!stats) return <div className="loading">Loading admin dashboard...</div>;

  return (
    <div className="page">
      <div className="hero compact">
        <div>
          <div className="eyebrow">ADMIN CONTROL CENTER</div>
          <h1>Assessment Management</h1>
          <p>Manage students, the question bank, and monitor overall system usage.</p>
        </div>
      </div>

      <div className="stat-grid">
        <div className="stat-card"><span>Students</span><strong>{stats.students}</strong></div>
        <div className="stat-card"><span>Not started</span><strong>{stats.students_not_started}</strong></div>
        <div className="stat-card"><span>Questions</span><strong>{stats.questions}</strong></div>
        <div className="stat-card"><span>Overall accuracy</span><strong>{stats.accuracy}%</strong></div>
      </div>

      <div className="two-column">
        <section className="panel">
          <div className="eyebrow">STUDENT ROSTER</div>
          <h2>{students.length} students</h2>

          <form className="question-form" onSubmit={submitStudent}>
            <input name="name" placeholder="Full name" value={studentForm.name} onChange={changeStudent} required />
            <input name="email" type="email" placeholder="Email" value={studentForm.email} onChange={changeStudent} required />
            <input name="password" type="password" placeholder="Password (min 6 chars)" value={studentForm.password} onChange={changeStudent} required minLength={6} />
            {studentError && <div className="error">{studentError}</div>}
            <button className="primary-btn">Create Student Account</button>
          </form>

          <div className="question-list">
            {students.map((s) => (
              <div className="question-row" key={s.id}>
                <div>
                  <b>{s.name}</b>
                  <small>{s.email} • {s.attempts} attempts • {s.accuracy}% accuracy • {s.ability}% ability • {s.status}</small>
                </div>
                <div className="row-actions">
                  <button className="ghost-btn" onClick={() => handleReset(s.id)}>Reset</button>
                  <button className="danger-btn" onClick={() => handleDelete(s.id)}>Delete</button>
                </div>
              </div>
            ))}
            {students.length === 0 && <p className="muted">No students yet.</p>}
          </div>
        </section>

        <section className="panel">
          <div className="eyebrow">QUESTION CREATOR</div>
          <h2>Add MCQ</h2>
          <form className="question-form" onSubmit={submit}>
            <textarea name="question_text" placeholder="Question" value={form.question_text} onChange={change} required />
            <input name="option_a" placeholder="Option A" value={form.option_a} onChange={change} required />
            <input name="option_b" placeholder="Option B" value={form.option_b} onChange={change} required />
            <input name="option_c" placeholder="Option C" value={form.option_c} onChange={change} required />
            <input name="option_d" placeholder="Option D" value={form.option_d} onChange={change} required />
            <div className="form-row">
              <input name="correct_answer" maxLength="1" placeholder="Correct A/B/C/D" value={form.correct_answer} onChange={change} required />
              <input name="difficulty" type="number" min="1" max="5" value={form.difficulty} onChange={change} />
            </div>
            <div className="form-row">
              <input name="topic" placeholder="Topic" value={form.topic} onChange={change} required />
              <input name="subtopic" placeholder="Subtopic" value={form.subtopic} onChange={change} required />
            </div>
            <textarea name="explanation" placeholder="Explanation" value={form.explanation} onChange={change} />
            <label className="check"><input type="checkbox" name="pre_assessment" checked={form.pre_assessment} onChange={change} /> Include in Level 0 pre-assessment</label>
            <button className="primary-btn">Create Question</button>
          </form>
        </section>
      </div>

      <section className="panel">
        <div className="eyebrow">QUESTION BANK</div>
        <h2>{questions.length} questions</h2>
        <div className="question-list">
          {questions.map((q) => (
            <div className="question-row" key={q.id}>
              <div>
                <b>#{q.id} {q.question_text}</b>
                <small>{q.topic} • {q.subtopic} • Difficulty {q.difficulty} • {q.pre_assessment ? "Level 0" : "Adaptive"}{!q.active ? " • Disabled" : ""}</small>
              </div>
              <button className="danger-btn" disabled={!q.active} onClick={() => remove(q.id)}>
                {q.active ? "Disable" : "Disabled"}
              </button>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

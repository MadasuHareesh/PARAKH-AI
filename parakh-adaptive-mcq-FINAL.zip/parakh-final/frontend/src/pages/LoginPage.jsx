import { useState } from "react";
import { login } from "../services/api";

export default function LoginPage({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const res = await login(email, password);
      localStorage.setItem("parakh_token", res.data.access_token);
      onLogin(res.data.user);
    } catch (err) {
      setError(err.response?.data?.detail || "Login failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="brand big">PARAKH<span>•AI</span></div>
        <p className="brand-sub">AI-Powered Adaptive MCQ Selection</p>

        <h1>Welcome back</h1>
        <p className="muted">Sign in to continue your adaptive assessment.</p>

        <form onSubmit={submit}>
          <label>Email</label>
          <input value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" />

          <label>Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="current-password"
          />

          {error && <div className="error">{error}</div>}

          <button className="primary-btn" type="submit" disabled={busy}>
            {busy ? "Signing in..." : "Login"}
          </button>
        </form>

        <div className="demo-box">
          <strong>Demo accounts (prototype only — remove before deployment)</strong>
          <br />
          Student: student@parakh.local / student123
          <br />
          Admin: admin@parakh.local / admin123
        </div>
      </div>
    </div>
  );
}
